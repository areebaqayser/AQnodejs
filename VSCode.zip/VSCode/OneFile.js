const fs = require('fs');
fs.writeFileSync('File.txt','Hello Class');