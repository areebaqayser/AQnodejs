// npm install prompt-sync
const prompt = require("prompt-sync")();

const input = prompt("What is your age? ");

console.log(`WOW! your age is ${input}`);