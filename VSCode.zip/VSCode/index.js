let message = "Hello world";
console.log(message);